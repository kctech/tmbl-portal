| Q                   | A
| --------------------| ---------------
| PHPUnit version     | x.y.z
| PHP version         | x.y.z
| Installation Method | Composer / PHAR

<!--
- Please fill in this template according to your issue.
- Please keep the table shown above at the top of your issue.
- Please include the output of "composer info | sort" if you installed PHPUnit using Composer.
- Please post code as text (using proper markup). Do not post screenshots of code.
- Visit https://phpunit.de/support.html if you are looking for support.
- Otherwise, replace this comment by the description of your issue.
-->

