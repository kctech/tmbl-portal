# From v4 to v5

The config file has been renamed. Change the name of the config file from `laravel-backup.php` to `backup.php`